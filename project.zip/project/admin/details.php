<?php 
session_start();


if(isset($_SESSION['username'])){

}else{
header("Location: index.php");
}

?>

<?php
   $con = mysqli_connect("localhost", "root","","admission");
   //print_r($_FILES);
   
   

?>

<?php
  $result = mysqli_query($con, "SELECT * FROM student where $_GET[id]=id");
 





?>




<html>
    <head>
      
        <title>User login || Details</title>
      
        <link rel="stylesheet" href="main.css">
 
    </head>

    <body>
     
        <div class="template clear">
		
		     <header class="headersection clear">
			     <h2>Admin Panel</h2>
				 <div class="manubar">
					 
					<ul> 
				        <li> <a href="logout.php">Logout</a></li>
				        <li> <a href="changepass.php">Change Password</a></li>
						<li><a href="pendingstudent.php">Pending Student</a></li>
				        
				    </ul>
				</div>
				 
			 </header>
			 
	<section class="contentsection clear">
			 
			 
	 <article class="maincontent clear">
	<div class="content">
                 <h2>Pending Student Details.</h2>
         <table class="mytable">
				 
				 
				 
				 
				 <?php 
				 $array= array();
				 
				 while($array= mysqli_fetch_array($result)){ ?>
				  
		<div class=adform>
             <form action="submit_admission.php" method="post" enctype="multipart/form-data">
	                                                                                   
			
				  <span style="padding-right: 5px;">&nbsp;</span>
					    <span">ID:</span>
					    <?php echo $array['id'] ?>
				 	 <hr>
				<div class="row">
					<span>Application for Admission: </span>
					<span style="padding-right: 5px; margin-left:20px">&nbsp;</span>
					<span>Year:</span>
					 <?php echo $array['year']?>
					<span style="padding-right: 5px; margin-left:150px">&nbsp;</span>
					<span>Semester:</span>
					<?php echo $array['semester'] ?>
					
					<span style="padding-right: 5px; margin-left: 30;  margin-left:150px">&nbsp;</span>
					    <span>Program:</span>
					    <?php echo $array['program'] ?>
			 </div>
			  <br>
					   <div class="row">
					                <span>Student type:</span>
							<span style=" margin-left:130px"><?php echo $array['studenttype'] ?></span>
					   </div>
			 <br>
					   
					   <div class="row">
							<span>Student Name : </span><span style="padding-right: 24px;">&nbsp;</span>
							<span style=" margin-left:84px"><?php echo $array['appname']?></span>
					
					   </div>
					  <br>
					  <div class="row">
							<span>Photo: </span><span style="padding-right: 77px">&nbsp;</span>
							
					  </div>
					<br>
				<div class="row">
						<span>Date of Birth (dd/mm/yyyy): </span><span style="padding-right: 3px; margin-left:37px"></span>
						 <?php echo $array['dateofbirth'] ?>
					    <span style="padding-right: 135px">&nbsp;</span>
						<span>Placeof Birth (District)</span>
						<span style="padding-right:20px"></span>
						<span><?php echo $array['placeofbirth']?></span>
						
				</div>
				<br>
				 <div class="row">
							<span>Gender: </span><span style="padding-right: 7px;">&nbsp;</span>
							 <?php echo $array['gender'] ?>
							<span style="padding-right: 338px;">&nbsp;</span>
							<span>Marital Status: </span><span style="padding-right:20px;">&nbsp;</span>
							<?php echo $array['maritalStatus'] ?>
				</div>
				<br>
				<div class="row">
						<span>Nationality: </span><span style="padding-right: 130px;">&nbsp;</span>
						  <?php echo $array['txtNationality'] ?>
						<span style="padding-right: 147px;">&nbsp;</span>
						<span>Blood Group: </span>
						<span style="padding-right: 21px;">&nbsp;</span>
						<?php echo $array['bloodGroup'] ?>
				</div>
					<br>  
					<div class="row">
						<span>Present Address:</span><span style="padding-right: 100px;">&nbsp;</span>
						
						 <?php echo $array['pads'] ?>
						
					</div>
					 <br>
					<div class="row">
						<span>Phone:</span><span style="padding-right: 160px;">&nbsp;</span>
						 <?php echo $array['txtPresentAddressPhone'] ?>
						<span class="required"></span>
						<span style="padding-right: 143px;">&nbsp;</span>
						<span>E-mail:</span>
						<span style="padding-right: 20px;">&nbsp;</span>
						<?php echo $array['email'] ?>
					</div>
					<br>
					<div class="row">
						<span>Permanent Address:</span><span style="padding-right: 80px;">&nbsp;</span>
							
							<?php echo $array['perads'] ?>
					</div>
			         <br>
					
					<div class="row">
						<span>Father's Name (in block letters): </span>
						<span style="padding-right: 0px;">&nbsp;</span>
						<?php echo $array['txtFathersName'] ?>
					</div>
					<br>
					
						<div class="row">
							<span>Occupation: </span>
							<span style="padding-right: 130px;">&nbsp;</span>
							 <?php echo $array['txtFatherOccupation'] ?>
							<span style="padding-right: 170px;">&nbsp;</span>
							<span>Address:</span><span style="padding-right: 20px;">&nbsp;</span>
							<?php echo $array['fads'] ?>
						</div>
						<br>
						<div class="row">
							<span>Phone: </span>
							<span style="padding-right: 160px;">&nbsp;</span>
							<?php echo $array['txtFatherPhone'] ?>
						</div>
					
					<br>
					<div class="row">
						<span>Mother's Name (in block letters): </span>
						<span style="padding-right: 0px;">&nbsp;</span>
						<?php echo $array['txtMothersName'] ?>
					</div>
					<br>
					
						<div class="row">
							<span>Occupation: </span><span style="padding-right: 130px;">&nbsp;</span>
							 <?php echo $array['txtMotherOccupation'] ?>
							<span style="padding-right: 160px;">&nbsp;</span>
							<span>Address:</span>
							<span style="padding-right: 20px;">&nbsp;</span>
							<?php echo $array['mads'] ?>
						</div>
						<br>
						<div class="row">
							<span>Phone: </span><span style="padding-right: 160px;">&nbsp;</span>
							<?php echo $array['txtMotherPhone'] ?>
						</div>
					   
					<br>
					<div class="row">
						<span>Name of Local Guardian: </span><span style="padding-right: 40px;">&nbsp;</span>
						
						<?php echo $array['txtLocalGuardianName'] ?>
					</div>
					<br>
					
						<div class="row">
							<span>Address:</span>
							<span style="padding-right: 145px;">&nbsp;</span>
							<?php echo $array['lgads'] ?>
						</div>
						<br>
						<div class="row">
							<span>Phone: </span><span style="padding-right: 160px;">&nbsp;</span>
							 <?php echo $array['txtLocalGuardianPhone'] ?>
							<span style="padding-right: 143px;">&nbsp;</span>
							<span>E-mail: </span><span style="padding-right: 20px;">
								&nbsp;</span>
								<?php echo $array['txtLocalGuardianEmail'] ?>
						</div>
					
					<br>
	
				<div class="row">
						<div class="row">
							<span style="font-size:20px">Academic Records:</span>
							
						</div>
						<br>
					
							<b>SSC/O'Level/Equivalent: </b>
						<table style="width: 97%;">
						  <tbody>
						       <tr>  
									<td style="text-align: center;">
										Name of Examination
									</td>
									<td style="text-align: center;">
										School/Institute
									</td>
									<td style="text-align: center;">
										Board/Institute
									</td>
									<td style="width: 16%; text-align: center;">
										Division/GPA
									</td>
									<td style="width: 16%; text-align: center;">
										Year of passing
									</td>
								</tr>
								
								<tr>
									<td style="text-align:center">
									<?php echo $array['txtSSCExamination'] ?>	
									</td>
									<td style="text-align:center">
									<?php echo $array['txtSSCSchoolName'] ?>
									</td>
									<td style="text-align:center">
									<?php echo $array['txtSSCBoard'] ?>
									</td>
									<td style="text-align:center">
									<?php echo $array['txtSSCGPA'] ?>
									</td>
									<td style="text-align:center">
									<?php echo $array['txtSSCPassingYear'] ?>
									</td>
								</tr>
								<br>
						  </tbody>
						</table>
					
					<br>
						
							<b>HSC/A'Level/Equivalent: </b><br>
						  <table style="width: 97%;">
								<tbody><tr>
									<td style="text-align: center;">
										Name of Examination
									</td>
									<td style="text-align: center;">
										College/Institute
									</td>
									<td style="text-align: center;">
										Board/Institute
									</td>
									<td style="width: 16%; text-align: center;">
										Division/GPA
									</td>
									<td style="width: 16%; text-align: center;">
										Year of passing
									</td>
								</tr>
								<br>
								<tr>
									<td style="text-align:center">
										<?php echo $array['txtHSCExamination'] ?>
									</td>
									<td style="text-align:center">
										<?php echo $array['txtHSCCollegeName'] ?>
									</td>
									<td style="text-align:center">
										<?php echo $array['txtHSCBoard'] ?>
									</td>
									<td style="text-align:center">
										<?php echo $array['txtHSCGPA'] ?>
									</td>
									<td style="text-align:center">
										<?php echo $array['txtHSCPassingYear'] ?>
									</td>
								</tr>
							 </tbody>
						 </table>
					 
					  <br>
					
							<b>Bachelor's Degree/Equivalent: </b>,<br>
						<table style="width: 97%;">
							<tbody>
							    <tr>
									<td style="text-align: center;">
										Name of Examination
									</td>
									<td style="text-align: center;">
										College/Institute/University
									</td>
									<td style="text-align: center;">
										Board/Institute
									</td>
									<td style="width: 16%; text-align: center;">
										Division/GPA
									</td>
									<td style="width: 16%; text-align: center;">
										Year of passing
									</td>
								</tr>
								<br>
								<tr>
									<td style="text-align:center">
										<?php echo $array['txtBScExamination'] ?>
									</td>
									<td style="text-align:center">
										<?php echo $array['txtBScUniversityName'] ?>
									</td>
									<td style="text-align:center">
										<?php echo $array['txtBScBoard'] ?>
									</td>
									<td style="text-align:center">
										<?php echo $array['txtBScGPA'] ?>
									</td>
									<td style="text-align:center">
										<?php echo $array['txtBScPassingYear'] ?>
									</td>
								</tr>
								<br>
								<br>
								<tr><td><b>Status</b></td> <td><?php echo $array['Status'] ?></td></tr>
							</tbody>
						</table>
					
					
		
				 
				
				
				 
				 

		
				 
				
				 
				
				 <?php }
				 
				 ?>
				 
				 
				 
		   
					
						
		</div>
	  

        </form>	
        </div>
        </table>	
       </div>
	 </article>
   </section>	 
			 <footer class="footersection clear">
			 <h3>&copy;copyright Bangladesh University.All Right Reserved</h3>
			 </footer>
			 
    	
    </body>
</html>
