<?php 


?>



<html>
    <head>
      
        <title>User login || change password</title>
      
        <link rel="stylesheet" href="main.css">
 
    </head>

    <body>
     
        <div class="template clear">
		
		     <header class="headersection clear">
			     <h2>Admin Panel</h2>
				 <div class="manubar">
					 
				     <ul> 
				        <li> <a href="logout.php">Logout</a></li>
				        <li> <a href="changepass.php">Change Password</a></li>
						<li><a href="pendingstudent.php">Pending Student</a></li>
				        
				     </ul>
				
				 </div>
			 </header>
			 
			 <section class="contentsection clear">
			 
			 
			 <article class="maincontent clear">
				<div class="content">
				     <h2>Change your password</h2>
					 
					 
					<form class="loginpage" action="" method="POST">
						<table>
						<tr>
						   <td>Old password:</td><td><input type="password" name="oldpass" placeholder="Please enter old password "/></td>
						</tr>
						<tr>
						   <td>New Password:</td><td><input type="password" name="newpass" placeholder="please enter new password"/></td>
						</tr>
						
						<tr>
						   <td></td><td><input type="Submit" name="submit" value="Update"/></td>
						</tr>
						</table>
					</form>
					        
				</div>
			 </article>
			 </section>
			 
			 <footer class="footersection clear">
			 <h3>&copy;copyright Bangladesh University.All Right Reserved</h3>
			 </footer>
		</div>
       
    </body>
</html>
