<?php 
session_start();

$html ="";
if(isset($_POST['submit'])){

if($_POST['username'] === 'admin' && $_POST['password'] === 'shahidul'){

$_SESSION['username'] = 'admin';

header("Location:home.php");

}else{

$html= "Username Or Password is wrong ";
}

}


?>

<?php 

    $con=mysqli_connect("localhost","root","","admission");
	
	
    $result="INSERT INTO `admin_tbl`(`id`, `username`, `password`) VALUES ('','username','password')";
    mysqli_query($con,$result);
  

	
?>
<?php
  if($_SERVER["REQUEST_METHOD"]=="POST"){
   $username=$_POST["username"];
   $password=$_POST["password"];
   
   echo "username".$username;
   echo "password".$password;
  }

?>


<html>
    <head>
      
        <title>User login</title>
      
        <link rel="stylesheet" href="main.css">
 
    </head>

    <body>
     
        <div class="template clear">
		
		     <header class="headersection clear">
			     <h2>Admin Panel</h2>
				
			 </header>
			 
			 <section class="contentsection clear">
			 
			 
			 <article class="maincontent clear">
				<div class="content">
				     <h2>Admin</h2>
					 
					 <?php echo $html; ?>
					<form class="loginpage" action="" method="POST">
						<table>
						<tr>
						   <td>Username:</td><td><input type="text" name="username" placeholder="Please enter username "/></td>
						</tr>
						<tr>
						   <td>Password:</td><td><input type="password" name="password" placeholder="please enter password"/></td>
						</tr>
						
						<tr>
						   <td></td><td><input type="Submit" name="submit" value="login"/></td>
						</tr>
						</table>
					</form>
					        
				</div>
			 </article>
			 </section>
			 
			 <footer class="footersection clear">
			 <h3>&copy;copyright Bangladesh University.All Right Reserved</h3>
			 </footer>
		</div>
       
    </body>
</html>
