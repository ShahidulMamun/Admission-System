
<?php 

    $con=mysqli_connect("localhost","root","","admission");
	
	//extract($_POST);
	
	
	  
    $result="INSERT INTO `student_status` (`id`, `Student_id`, `Status`) VALUES ('','$Student_id','$Status')";
    mysqli_query($con,$result);
  
 
    //print_r($_POST);
	 echo "Accepted";
	
?>
<?php
 if($_SERVER["REQUEST_METHOD"]=="POST"){
		   $Student_id    =$_POST["Student_id"];
		   $Status        =$_POST["Status"];
		 
		   
		 echo "Student_id:".$Student_id;
		 echo "Status:".$Status;
		
		   }
		   
		
		   function validate($data){
		      $data = trim($data);
			  $data = stripcslashes($data);
			  $data = htmlspecialchars($data);
		       return $data;
		   
		   }
?>