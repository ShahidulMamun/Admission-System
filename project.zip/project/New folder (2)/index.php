<!DOCTYPE>
<html>

<head>
<title>Bangladesh University</title>



<link rel="stylesheet" href="style.css">

</head> 

<body> 


<div class="headersection templete clear">
<div class="logo clear">
<img src="images/logo.jpg" alt="logo"/>
<h1>Bangladesh university</h1>
</div>

<div class="social clear">
<ul>
<li><a target="blank" href ="admin.php">Login</a></li>
</ul>
</div>
</div>



</div>

<div class="navsection templete clear">

<ul>
<li> <a href="#">Home</a></li>
<li> <a href="#">About</a></li>
<li> <a href="#">Academics</a></li>
<li> <a href="Admission.php">Admission</a></li>
<li> <a href="#">Contact</a></li>
</ul>

	<div id="lsearch">
		<form  method="get" action="">
		        <input type="text" name="q" size="20" maxlength="120" placeholder="search...."/>
				<input type="submit" name="submit" value="search"/>
		</form>
	
	</div>



</div>




<div class="contentsection templete clear">


<div class="maincontent clear">
<div class="samepost clear">
<h2>Welcome to Bangladesh University</h2>
<img src="images\post1.jpg"/>

<p>Established in 2001, Bangladesh University has 
provided quality higher education at a minimum cost
 especially for the financially disadvantaged.
 For more than a decade now, BU has increased
 and nurtured talent within the youth with modern
 knowledge and technology.With our international 
 affiliations, at BU, our aim is to make our students
 capable and ethical leaders who will lead and represent
 our nation around the world....
 </p>


</div>
<div class="read clear"><a href="#">Read more</a></div>



<div class="samepost clear">
<h2>First 3D Printer Lab in Bd</h2>
<img src="images\post2.jpg"/>

<p>Department of Computer Science & Engineering is cordially thankful
 to our Honorable Chief Guest Mr. Zunaid Ahmed Palak, Honorable State
 Minister ( Posts and ICT ), Eminent Professor Dr. Mohammad Kaykobad 
 sir, BUET and also other respective guests who was present at the 
 Inauguration of the first 3D Printers Lab in Bangladesh at our 
 Bangladesh University.....
</p>


</div>
<div class="read clear"><a href="#">Read more</a></div>

<div class="relatedarticle clear ">
<h2>More Article</h2>
<a href="#"><img src="images\r1.jpg"/></a>
<a href="#"><img src="images\r2.jpg"/></a>
<a href="#"><img src="images\r3.jpg"/></a>
<a href="#"><img src="images\r4.jpg"/></a>
<a href="#"><img src="images\r5.jpg"/></a>
<a href="#"><img src="images\r6.jpg"/></a>

 </div>
 </div>
 
<div class="sidbar clear">
<div class="samesidbar clear">
<h2>BU Navigation</h2>

<ul>
<li> <a href="#"><em>Academic Calender</em></a></li>
<li> <a href="#"><em>Seminar</em></a></li>
<li> <a href="#"><em>Tuition Award</em></a></li>
<li> <a href="#"><em>Freshers  Orientation</em></a></li>
<li> <a href="#"><em>Publications</em></a></li>
<li> <a href="#"><em>News & Events</em> </a></li>
<li> <a href="#"><em>Department/School</em> </a></li>
<li> <a href="#"><em>Extra/Co-Curricular Activities</em></a></li>
<li> <a href="#"><em>International Advisory Council</em></a></li>
</div>

</div>
<div class="samesidbar clear">
	 <h2><em>Events</em></h2>

          <h3>Documetary of CSE department</h3>
			<iframe   
			        width="250" height="120" src="https://www.youtube.com/embed/1sYks8E4yHA" frameborder="0" allowfullscreen>
			
			</iframe>
			
			 <h3>Documetary of CSE department</h3>
			<iframe 
			       width="250" height="120" src="https://www.youtube.com/embed/LZuL6ef3jQM" frameborder="0" allowfullscreen>
			
			</iframe>
               <h3>Documetary of CSE department</h3>
            <iframe
			       width="250" height="120" src="https://www.youtube.com/embed/RDEPzfBf44o" frameborder="0" allowfullscreen>
			  
			</iframe>
			    

</div>

 </div>
 <div class="footer templete clear">
 
		 <div class="bottombar templete clear">
			
			<a href=""#><img src="images/logo.jpg" alt=logo/></a>
	
           <div class="address templete clear">
		          
			        <p>Information Desk</p>
					<p>+8801744-291258, +8802-9136061</p>
					<p>Admission Section:</p>
					<p>+8801755-559301,Email: info@bu.edu.bd</p>
					<p>15/1, Iqbal Road,Mohammadpur</p>
					<p>Dhaka1207,Bangladesh</p>
			</div>
			</div>
		 <div class="footermanu clear">
				 <ul>

					 <li><a href="#">Home</a></li>
					 <li><a href="#">Contact</a></li>
					 <li><a href="#">About</a></li>
					 <li><a href="#">Media</a></li>
				 
				</ul>
		  
		 </div>
 
            <p>&copy;Copyright Bangladesh University.All Right Reserved.</p>
			
 </div>

</body>

 
</html>
