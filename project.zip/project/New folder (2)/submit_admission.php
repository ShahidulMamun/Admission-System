
<?php 

    $con=mysqli_connect("localhost","root","","admission");
	
	extract($_POST);
	
	
	
    $result="INSERT INTO `student` (`id`, `year`, `semester`, `program`, `studenttype`, `appname`, `dateofbirth`, `placeofbirth`,
	`gender`, `maritalStatus`, `txtNationality`, `bloodGroup`,`pads`, `txtPresentAddressPhone`, `email`, `perads`, `txtFathersName`, 
	`txtFatherOccupation`, `fads`, `txtFatherPhone`, `txtMothersName`, `txtMotherOccupation`, `mads`, `txtMotherPhone`, `txtLocalGuardianName`,
	`lgads`, `txtLocalGuardianPhone`, `txtLocalGuardianEmail`, `txtSSCExamination`, `txtSSCSchoolName`, `txtSSCBoard`, `txtSSCGPA`, `txtSSCPassingYear`,
	`txtHSCExamination`, `txtHSCCollegeName`, `txtHSCBoard`, `txtHSCGPA`, `txtHSCPassingYear`, `txtBScExamination`, `txtBScUniversityName`, `txtBScBoard`, 
	`txtBScGPA`, `txtBScPassingYear`)
	VALUES ('','$year','$semester','$program','$studenttype','$appname','$dateofbirth','$placeofbirth','$gender','$maritalStatus',
	'$txtNationality','$bloodGroup','$pads','$txtPresentAddressPhone','$email','$perads','$txtFathersName','$txtFatherOccupation','$fads',
	'$txtFatherPhone','$txtMothersName','$txtMotherOccupation','$mads','$txtMotherPhone','$txtLocalGuardianName','$lgads','$txtLocalGuardianPhone',
	'$txtLocalGuardianEmail','$txtSSCExamination','$txtSSCSchoolName','$txtSSCBoard','$txtSSCGPA','$txtSSCPassingYear','$txtHSCExamination','$txtHSCCollegeName',
	'$txtHSCBoard','$txtHSCGPA','$txtHSCPassingYear','$txtBScExamination','$txtBScUniversityName','$txtBScBoard','$txtBScGPA','$txtBScPassingYear')";
    mysqli_query($con,$result);
  
 
    //print_r($_POST);
	 echo "Your information has successfully submitted";
	
?>