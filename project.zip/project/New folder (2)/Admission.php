<!DOCTYPE>
<html>

<head>
<title>Bangladesh University</title>



<link rel="stylesheet" href="style.css">

</head> 

<body> 


<div class="headersection templete clear">
<div class="logo clear">
<img src="images/logo.jpg" alt="logo"/>
<h1>Bangladesh university</h1>
</div>

<div class="social clear">
<ul>
<li><a href="https://buportal.cloudapp.net/LoginPage.aspx">Login</a></li>
</ul>
</div>
</div>



</div>

<div class="navsection templete clear">

<ul>
<li> <a href="Index.php">Home</a></li>
<li> <a href="#">About</a></li>
<li> <a href="#">Academics</a></li>
<li> <a href="Admission.php">Admission</a></li>
<li> <a href="#">Contact</a></li>
</ul>
		<div id="lsearch">
				<form  method="get" action="">
						<input type="text" name="q" size="20" maxlength="120" placeholder="search...."/>
						<input type="submit" name="submit" value="search"/>
				</form>
			
		</div>
</form>
</div>



<div class="contentsection templete clear">


<div class="maincontent clear">
<div class="samepost clear">

<a href="admissionform.php">Admission Form</a>
<h2>Admission Requirement</h2>
<img src="images\adreq1.jpg"/>

<p>The candidate must have a minimum of GPA 2.50 individually in both
 SSC and HSC. Alternatively, if the candidate fails to achieve the minimum
 GPA of 2.50 in either SSC or HSC, then he must have a total GPA of 6.00
Minimum GPA of 2.5 in O-Levels in five subjects and A-Levels in two 
subjects and total GPA 6.0 according to Bangladesh University scale 
(A=5, B=4, C=3 and D=2). Subjects with E Grade will not be considered..
 </p>


</div>
<div class="read clear"><a href="#">Read more</a></div>
<div class="samepost clear">
<h2>Registration Procedure</h2>
<img src="images\adreq2.jpg"/>

<p>Every student must submit the required certificates and other documents at the 
time of admission. Applicants for admission who are not able to produce one or
 more documents at the time of admission may be admitted provisionally.
 All provisionally admitted students are required to submit appropriate documents 
 within a given deadline as a prerequisite for..

</div>
<div class="read clear"><a href="#">Read more</a></div>



<div class="samepost clear">
<h2>Course Fee,Funding and Aid</h2>
<img src="images\adreq3.jpg"/>

<p>Up to 100% tuition fee waiver to those who obtained GPA of 5.0 (Golden) in SSC and HSC
 from Science, Arts and Commerce groups

Physically challenged students, ethnic minority group, sibling, spouse will receive 
special fee waiver at various rates to be determined by the Scholarship Committee on a case-by-case basis.

Up to 100% tuition fee waiver for freedom fighter`s son/daughter..
</p>


</div>
<div class="read clear"><a href="#">Read more</a></div>


 </div>
 

 </div>
<div class="footer templete clear">
 
		 <div class="bottombar templete clear">
			
			<a href=""#><img src="images/logo.jpg" alt=logo/></a>
	
           <div class="address templete clear">
		          
			        <p>Information Desk</p>
					<p>+8801744-291258, +8802-9136061</p>
					<p>Admission Section:</p>
					<p>+8801755-559301,Email: info@bu.edu.bd</p>
					<p>15/1, Iqbal Road,Mohammadpur</p>
					<p>Dhaka1207,Bangladesh</p>
			</div>
			</div>
		 <div class="footermanu clear">
				 <ul>

					 <li><a href="#">Home</a></li>
					 <li><a href="#">Contact</a></li>
					 <li><a href="#">About</a></li>
					 <li><a href="#">Media</a></li>
				 
				</ul>
		  
		 </div>
 
            <p>&copy;Copyright Bangladesh University.All Right Reserved.</p>
			
 </div>

 

 

</body>


</html>

