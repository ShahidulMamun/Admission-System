<!DOCTYPE>
<html>

<head>
<title>Bangladesh University</title>



<link rel="stylesheet" href="style.css">

</head> 
 
<?php




		   if($_SERVER["REQUEST_METHOD"]=="POST"){
		   $year             =$_POST["year"];
		   $Semester         =$_POST["semester"];
		   $Program          =$_POST["program"];
		   $studenttype      =$_POST["studenttype"];
		   $Name             =$_POST["appname"];
		   $Photo            =$_POST["photo"];
		   $Date_of_Birth    =$_POST["dateofbirth"];
		   $Placeof_Birth    =$_POST["placeofbirth"];
		   $gender          =$_POST["gender"];
		   $Marital_Status  =$_POST["maritalStatus"];
		   $Nationality     =$_POST["txtNationality"];
		   $Blood_Group     =$_POST["bloodGroup"];
		   $Present_Address =$_POST["pads"];
		   $Phone           =$_POST["txtPresentAddressPhone"];
		   $Email           =$_POST["email"];
		   $Permanent_Address =$_POST["perads"];
		   $Fathers_name    =$_POST["txtFathersName"];
		   $Occupation      =$_POST["txtFatherOccupation"];
		   $Address         =$_POST["fads"];
		   $Phone           =$_POST["txtFatherPhone"];
		   $Mothers_Name    =$_POST["txtMothersName"];
		   $Occupation      =$_POST["txtMotherOccupation"];
		   $Address         =$_POST["mads"];
		   $Phone           =$_POST["txtMotherPhone"];
		   $Name_of_Local_Guardian  =$_POST["txtLocalGuardianName"];
		   $Address         =$_POST["lgads"];
		   $Phone           =$_POST["txtLocalGuardianPhone"];
		   $Name_of_Examination =$_POST["txtSSCExamination"];
		   $School_Institute =$_POST["txtSSCSchoolName"];
		   $Board_Institute  =$_POST["txtSSCBoard"];
		   $GPA              =$_POST["txtSSCGPA"];
		   $Year_of_passing  =$_POST["txtSSCPassingYear"];
		   $Name_of_Examination =$_POST["txtHSCExamination"]; 
		   $College_Institute =$_POST["txtHSCCollegeName"]; 
		   $Board            =$_POST["txtHSCBoard"];
		   $GPA              =$_POST["txtHSCGPA"];
		   $Year_of_passing  =$_POST["txtHSCPassingYear"];
		   $Name_of_Examination =$_POST["txtBScExamination"];
		   $College_Institute_University =$_POST["txtBScUniversityName"];
		   $Board_Institute =$_POST["txtBScBoard"];
		   $GPA =$_POST["txtBScGPA"];
		   $Year_of_passing =$_POST["txtBScPassingYear"];
		   $status =$_POST["status"];
		   
		   
		
		echo "Year:".$year;
		echo "Semester:".$Semester;
		echo "Program:".$Program;
		echo "Student Type:".$studenttype;
		echo "Name:".$Name;
		echo "Photo:".$Photo;
		echo "Date of Birth:".$Date_of_Birth;
		echo "Place of Birth:".$Placeof_Birth;
		echo "gender:".$Gender;
		echo "maritalStatus:".$Marital_Status;
		echo "Nationality:".$Nationality;
		echo "Blood Group:".$Blood_Group;
		echo "Present Address:".$Present_Address;
		echo "Phone :".$Phone;
		echo "Email:".$Email;
		echo "Permanent Address:".$Permanent_Address;
		echo "Father's Name :".$Fathers_name;
		echo "Occupation:".$Occupation;
		echo "Address:".$Address;
		echo "Mothers Name:".$Mothers_Name;
		echo "Occupation:".$Occupation;
		echo "Address:".$Address;
		echo "Phone:".$Phone;
		echo "Name of Local Guardian:".$Name_of_Local_Guardian;
		echo "Address :".$Address;
		echo "Phone:".$Phone;
		echo "Name of Examination:".$Name_of_Examination;
		echo "School Institute:".$School_Institute;
		echo "Board_Institute:".$Board_Institute;
		echo "GPA:".$GPA;
		echo "$Year of passing:".$Year_of_passing;
		echo "Name of Examination".$Name_of_Examination;
		echo "College/Institute:".$College_Institute;
		echo "Board :".$Board;
		echo "Year of passing:".$Year_of_passing;
		echo "Name of Examination:".$Name_of_Examination;
		echo "College/Institute/University:".$College_Institute_University;
		echo "Board/Institute :".$Board_Institute;
		echo "GPA:".$GPA;
		echo "$Year of passing:".$Year_of_passing;
		echo "Status".$status;
		 
		   }
		   function validate($data){
		      $data = trim($data);
			  $data = stripcslashes($data);
			  $data = htmlspecialchars($data);
		       return $data;
		   
		   }
		   
		   
		  ?>
		  
		
<body> 


<div class="headersection templete clear">
<div class="logo clear">
<img src="images/logo.jpg" alt="logo"/>
<h1>Bangladesh university</h1>
</div>

<div class="social clear">
<ul>
<li><a href="https://buportal.cloudapp.net/LoginPage.aspx">Login</a></li>
</ul>
</div>
</div>


<div class="navsection templete clear">

				<ul>
				<li> <a href ="Index.php">Home</a></li>
				<li> <a href="#">About</a></li>
				<li> <a href="#">Academics</a></li>
				<li> <a href="Admission.php">Admission</a></li>
				<li> <a href="#">Contact</a></li>
				</ul>
				
			<div id="lsearch">
					<form  method="get" action="">
							<input type="text" name="q" size="20" maxlength="120" placeholder="search...."/>
							<input type="submit" name="submit" value="search"/>
					</form>
	
	      </div>
</div>



<div class="contentsection templete clear">

  <div class=adform>
         <form action="submit_admission.php" method="post" enctype="multipart/form-data">
			<div>
				
				<div class="row">
					<span>Application for Admission: </span>
					<span style="padding-right: 5px;">&nbsp;</span>
					<span>Year</span>
					<input type="text" name="year"  size="4" maxlength="4" value="2017"/>
					
					<span style="padding-right: 5px;">&nbsp;</span>
					<span>Semester</span>
					
					<select name="semester">
			
									<option value="Spring">Spring</option>
									<option value="Summer">Summer</option>
									<option value="Fall">Fall</option>

					</select>
					<span style="padding-right: 5px;">&nbsp;</span>
					    <span>Program</span>
					    <select name="program" style="width: 226px;">
					
									<option  value="BBA">BBA</option>
									<option  value="BA Eng">BA Eng</option>
									<option  value="BSS Economics">BSS Economics</option>
									<option  value="Bss Sociology">Bss Sociology</option>
									<option  value="LLB (Hon)">LLB (Hon)</option>
									<option  value="Bsc Mathematics">Bsc Mathematics</option>
									<option  value="B.sc in CSE">B.sc in CSE</option>
									<option  value="B.sc in CSE (Diploma))">B.sc in CSE (Diploma)</option>
									<option  value="B. Pharm">B. Pharm</option>
									<option  value="Bachelor of Architecture">Bachelor of Architecture</option>
									<option  value="B.sc in EEE">B.sc in EEE</option>
									<option  value="B.sc in EEE (Diploma)">B.sc in EEE (Diploma)</option>
									<option  value="Architecture (Diploma)">Architecture (Diploma)</option>
									<option  value="MBA (Regular)">MBA (Regular)</option>
									<option  value="MBA (Executive)">MBA (Executive)</option>
									<option  value="MBA for BBA Holders">MBA for BBA Holders</option>
									<option  value="MBA for BBA Holders">MBA for BBA Holders BU</option>
									<option  value="MBA others students BU">MBA others students BU</option>
									<option  value="MBA for BBA Holders">MA in English (2years)</option>
									<option  value="MBA for BBA Holders">LL.B Degree (2Year))</option>
									<option  value="MA in English BU">MA in English BU</option>
									<option  value="MA in English BU">MA in English other </option>
									<option  value="MA in English BU">LLM BU (1year)</option>
									<option  value="LLM other (1Year)">LLM other (1Year)</option>

					    </select>
			 </div>
					   <div class="row">
					                <span>Student type</span>
									<span style="padding-right: 178px;">&nbsp;</span>
									<input type="radio" name="studenttype" value="Regular"><label>Regular</label>
									<input type="radio" name="studenttype" value="Transfered"><label>Transfered</label>
									<input type="radio" name="studenttype" value="diploma"><label>Diploma</label>
					   </div>
					   
					   <div class="row">
							<span>Name (in block letters): </span><span style="padding-right: 24px;">&nbsp;</span>
							<input name="appname"style="width:550px" type="text"/>
					
					   </div>
					  
					  <div class="row">
							<b>Photo upload: </b><span style="padding-right: 77px">&nbsp;</span><input type="file" style="width:100px;"name="photo">
							<span style="color: red; padding-left: 59px;"></span>
					  </div>
					
				<div class="row">
						<span>Date of Birth (dd/mm/yyyy): </span><span style="padding-right: 3px;"></span>
						<input type="date" name="dateofbirth" size="10" maxlength="10">
					    <span style="padding-right: 135px">&nbsp;</span>
						<span>Placeof Birth (District)</span>
						
						<select name="placeofbirth"/>
							<option value=""></option>
							<option value="Barguna">Barguna</option>
							<option value="Bagerhat">Bagerhat</option>
							<option value="Bandarban">Bandarban</option>
							<option value="Barisal">Barisal</option>
							<option value="Bhola">Bhola</option>
							<option value="Bogra">Bogra</option>
							<option value="Brahmanbaria">Brahmanbaria</option>
							<option value="Chandpur">Chandpur</option>
							<option value="Chapainababganj">Chapainababganj</option>
							<option value="Chittagong">Chittagong</option>
							<option value="Chuadanga">Chuadanga</option>
							<option value="Comilla">Comilla</option>
							<option value="Cox's Bazar">Cox's Bazar</option>
							<option value="Dhaka">Dhaka</option>
							<option value="Dinajpur">Dinajpur</option>
							<option value="Faridpur">Faridpur</option>
							<option value="Feni">Feni</option>
							<option value="Gaibandha">Gaibandha</option>
							<option value="Gazipur">Gazipur</option>
							<option value="Gopalganj">Gopalganj</option>
							<option value="Habiganj">Habiganj</option>
							<option value="Jamalpur">Jamalpur</option>
							<option value="Jessore">Jessore</option>
							<option value="Jhalokati">Jhalokati</option>
							<option value="Jhenaidah">Jhenaidah</option>
							<option value="Joypurhat">Joypurhat</option>
							<option value="Khagrachhari">Khagrachhari</option>
							<option value="Khulna">Khulna</option>
							<option value="Kishoregonj">Kishoregonj</option>
							<option value="Kurigram">Kurigram</option>
							<option value="Kushtia">Kushtia</option>
							<option value="Lakshmipur">Lakshmipur</option>
							<option value="Lalmonirhat">Lalmonirhat</option>
							<option value="Madaripur">Madaripur</option>
							<option value="Magura">Magura</option>
							<option value="Manikganj">Manikganj</option>
							<option value="Maulvibazar">Maulvibazar</option>
							<option value="Meherpur">Meherpur</option>
							<option value="Munshiganj">Munshiganj</option>
							<option value="Mymensingh">Mymensingh</option>
							<option value="Naogaon">Naogaon</option>
							<option value="Narail">Narail</option>
							<option value="Narayanganj">Narayanganj</option>
							<option value="Narsingdi">Narsingdi</option>
							<option value="Natore">Natore</option>
							<option value="Netrakona">Netrakona</option>
							<option value="Nilphamari">Nilphamari</option>
							<option value="Noakhali">Noakhali</option>
							<option value="Pabna">Pabna</option>
							<option value="Panchagarh">Panchagarh</option>
							<option value="Patuakhali">Patuakhali</option>
							<option value="Pirojpur">Pirojpur</option>
							<option value="Rajbari">Rajbari</option>
							<option value="Rajshahi">Rajshahi</option>
							<option value="Rangamati">Rangamati</option>
							<option value="Rangpur">Rangpur</option>
							<option value="Satkhira">Satkhira</option>
							<option value="Shariatpur">Shariatpur</option>
							<option value="Sherpur">Sherpur</option>
							<option value="Sirajganj">Sirajganj</option>
							<option value="Sunamganj">Sunamganj</option>
							<option value="Sylhet">Sylhet</option>
							<option value="Tangail">Tangail</option>
							<option value="Thakurgaon">Thakurgaon</option>

						</select>
				</div>
				 <div class="row">
							<span>Gender: </span><span style="padding-right: 7px;">&nbsp;</span>
							<span style="vertical-align: sub;"><input type="radio" name="gender" value="Male"> </span>Male
							<span style="vertical-align: sub;"><input type="radio" name="gender" value="Female"> </span>Female
							
							<span style="padding-right: 203px;">&nbsp;</span>
							<span>Marital Status: </span><span style="padding-right: 35px;">
								&nbsp;</span>
							<span style="vertical-align: sub;"><input type="radio" name="maritalStatus" value="Married"></span>Married
							<span style="vertical-align: sub;"><input type="radio" name="maritalStatus" value="Single"></span>Single
				</div>
				<div class="row">
						<span>Nationality: </span><span style="padding-right: 0px;">&nbsp;</span>
						<input type="text" name="txtNationality"/>
						<span style="padding-right: 183px;">&nbsp;</span>
						<span>Blood Group: </span>
						<span style="padding-right: 21px;">&nbsp;</span>
						<select name="bloodGroup">
							<option value=""></option>
							<option value="O-">O-</option>
							<option value="O+">O+</option>
							<option value="A-">A-</option>
							<option value="A+">A+</option>
							<option value="B-">B-</option>
							<option value="B+">B+</option>
							<option value="AB-">AB-</option>
							<option value="AB+">AB+</option>

						</select>
				</div>
					<br>
					<div class="row">
						<span>Present Address:</span><span style="padding-right: 3px;">&nbsp;</span>
						<textarea name="pads" cols="74" rows="3"></textarea>
					</div>
					<div class="row">
						<span>Phone:</span><span style="padding-right: 3px;">&nbsp;</span>
						<input type="phone" name="txtPresentAddressPhone"/>
						<span class="required"></span>
						<span style="padding-right: 17px;">&nbsp;</span>
						<span>E-mail:</span>
						<span style="padding-right: 3px;">&nbsp;</span>
						<input type="email" name="email" style="width: 388px">
					</div>
					<div class="row">
						<span>Permanent Address:</span><span style="padding-right: 3px;">&nbsp;</span>
						<textarea name="perads" cols="72" rows="3"></textarea>		<br>
					</div>
			         <br>
					
					<div class="row">
						<span>Father's Name (in block letters): </span>
						<span style="padding-right: 0px;">&nbsp;</span>
						<input type="text" name="txtFathersName" style="width:524px;"/>
					</div>
					<div style="margin-left: 10px;">
						<div class="row">
							<span>Occupation: </span>
							<span style="padding-right: 3px;">&nbsp;</span>
							<input type="text" name="txtFatherOccupation"/>
							<span style="padding-right: 10px;">&nbsp;</span>
							<span>Address:</span><span style="padding-right: 3px;">&nbsp;</span>
							<textarea name="fads" rows="3" cols="41"></textarea>
						</div>
						<div class="row">
							<span>Phone: </span>
							<span style="padding-right: 34px;">&nbsp;</span>
							<input type="phone" name="txtFatherPhone"/>
						</div>
					</div>
					<br>
					<div class="row">
						<span>Mother's Name (in block letters): </span>
						<span style="padding-right: 0px;">&nbsp;</span>
						<input type="text" name="txtMothersName" style="width: 526px;">
					</div>
					<div style="margin-left: 10px;">
						<div class="row">
							<span>Occupation: </span><span style="padding-right: 7px;">&nbsp;</span>
							<input type="text" name="txtMotherOccupation"/>
							<span style="padding-right: 10px;">&nbsp;</span>
							<span>Address:</span>
							<span style="padding-right: 3px;">&nbsp;</span>
							<textarea name="mads" rows="3" cols="42"></textarea>
						</div>
						<div class="row">
							<span>Phone: </span><span style="padding-right: 34px;">&nbsp;</span>
							<input type="text" name="txtMotherPhone"/>
						</div>
					</div>
					<br>
					<div class="row">
						<span>Name of Local Guardian: </span><span style="padding-right: 3px;">&nbsp;</span>
						<input type="text" name="txtLocalGuardianName" style="width: 278px;">
						(if parents live outside Dhaka)
					</div>
					<div style="margin-left: 10px;">
						<div class="row">
							<span>Address:</span>
							<span style="padding-right: 3px;">&nbsp;</span>
							<textarea name="lgads" rows="3" cols="82"></textarea>
						</div>
						<div class="row">
							<span>Phone: </span><span style="padding-right: 14px;">&nbsp;</span>
							<input type="text" name="txtLocalGuardianPhone"/>
							<span style="padding-right: 28px;">&nbsp;</span><span>E-mail: </span><span style="padding-right: 14px;">
								&nbsp;</span>
								<input type="email" name="txtLocalGuardianEmail" style="width: 367px;"/>
						</div>
					</div>
					<br>
	
				<div class="row">
						<div class="row">
							<span>Academic Records:</span><br>
						</div>
					<div class="row" style="width: 92%; padding-left: 5px;">
							<b>SSC/O'Level/Equivalent: </b>
						<table style="width: 100%;">
						  <tbody>
						       <tr>
									<td style="text-align: center;">
										Name of Examination
									</td>
									<td style="text-align: center;">
										School/Institute
									</td>
									<td style="text-align: center;">
										Board/Institute
									</td>
									<td style="width: 16%; text-align: center;">
										Division/GPA
									</td>
									<td style="width: 16%; text-align: center;">
										Year of passing
									</td>
								</tr>
								<tr>
									<td>
										<input type="text" name="txtSSCExamination" style="width: 100%;">
									</td>
									<td>
										<input type="text" name="txtSSCSchoolName" style="width: 100%;">
									</td>
									<td>
										<input type="text" name="txtSSCBoard"  style="width: 100%;">
									</td>
									<td>
										<input type="text" name="txtSSCGPA"  style="width: 100%; text-align: center;">
									</td>
									<td>
										<input type="text" name="txtSSCPassingYear"  style="width: 100%; text-align: center;" maxlength="4">
									</td>
								</tr>
						  </tbody>
						</table>
					</div>
						<div class="row" style="width: 92%; padding-left: 5px;">
							<b>HSC/A'Level/Equivalent: </b>
						  <table style="width: 100%;">
								<tbody><tr>
									<td style="text-align: center;">
										Name of Examination
									</td>
									<td style="text-align: center;">
										College/Institute
									</td>
									<td style="text-align: center;">
										Board/Institute
									</td>
									<td style="width: 16%; text-align: center;">
										Division/GPA
									</td>
									<td style="width: 16%; text-align: center;">
										Year of passing
									</td>
								</tr>
								<tr>
									<td>
										<input type="text" name="txtHSCExamination" style="width: 100%;"/>
									</td>
									<td>
										<input type="text" name="txtHSCCollegeName" style="width: 100%;"/>
									</td>
									<td>
										<input type="text" name="txtHSCBoard"  style="width: 100%;"/>
									</td>
									<td>
										<input type="text" name="txtHSCGPA"style="width: 100%; text-align: center;"/>
									</td>
									<td>
										<input type="text" name="txtHSCPassingYear"style="width: 100%; text-align: center;" maxlength="4"/>
									</td>
								</tr>
							 </tbody>
						 </table>
					  </div>
					<div class="row" style="width: 92%; padding-left: 5px;">
							<b>Bachelor's Degree/Equivalent: </b>
						<table style="width: 100%;">
							<tbody>
							    <tr>
									<td style="text-align: center;">
										Name of Examination
									</td>
									<td style="text-align: center;">
										College/Institute/University
									</td>
									<td style="text-align: center;">
										Board/Institute
									</td>
									<td style="width: 16%; text-align: center;">
										Division/GPA
									</td>
									<td style="width: 16%; text-align: center;">
										Year of passing
									</td>
								</tr>
								<tr>
									<td>
										<input type="text" name="txtBScExamination"  style="width: 100%;">
									</td>
									<td>
										<input type="text" name="txtBScUniversityName"  style="width: 100%;">
									</td>
									<td>
										<input type="text" name="txtBScBoard"  style="width: 100%;">
									</td>
									<td>
										<input type="text" name="txtBScGPA" style="width: 100%; text-align: center;">
									</td>
									<td>
										<input type="text" name="txtBScPassingYear"  style="width: 100%; text-align: center;" maxlength="4">
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					
				</div>
				
					
					
				
			
				<div class="row">
					
					<br>
					
					<br>
					<div style="height: 30px">
						<span style="float: right; padding-right:48px; padding:10px 15px;margin-right:20px" color="white">
							<input type="submit" value="Apply">
							
					    </span>
					</div>
					
				</div>
		 
		  </form>
          

		
	  </div>
				  
																
	
				            
   </div>
   
   
</div>
 <div class="footer templete clear">
 
		 <div class="bottombar templete clear">
			
			<a href=""#><img src="images/logo.jpg" alt=logo/></a>
	
           <div class="address templete clear">
		          
			        <p>Information Desk</p>
					<p>+8801744-291258, +8802-9136061</p>
					<p>Admission Section:</p>
					<p>+8801755-559301,Email: info@bu.edu.bd</p>
					<p>15/1, Iqbal Road,Mohammadpur</p>
					<p>Dhaka1207,Bangladesh</p>
			</div>
			</div>
		 <div class="footermanu clear">
				 <ul>

					 <li><a href="#">Home</a></li>
					 <li><a href="#">Contact</a></li>
					 <li><a href="#">About</a></li>
					 <li><a href="#">Media</a></li>
				 
				</ul>
		  
		 </div>
 
            <p>&copy;Copyright Bangladesh University.All Right Reserved.</p>
			
 </div>

 

 

</body>


</html>

